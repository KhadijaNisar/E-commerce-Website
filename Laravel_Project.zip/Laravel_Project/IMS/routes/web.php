<?php
use App\Http\Controllers\categoryController;
use App\Http\Controllers\dashboardController;
use App\Http\Controllers\supplierController;
use App\Http\Controllers\auth;
use App\Http\Controllers\productController;
use App\Http\Controllers\RegisterController;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Register Route
Route::get('/auth/register', [auth::class,'register'])->name('auth.register');
//Save Route
Route::post('/auth/save', [auth::class,'save'])->name('auth.save');
//CheckRoute
Route::post('/auth/check', [auth::class,'doAuthentication'])->name('auth.check');
//Log out Route
Route::get('/auth/logout', function () {
    if(session()->has('sessionName')){
        session()->pull('sessionName');
    }
    return redirect('/auth/login');
});


//Login Route
Route::get('/auth/login', [auth::class,'login'])->name('auth.login');


Route::get('/', function () {
    return view('welcome');
});


Route::get('/dashboard', [dashboardController::class, 'countRows'])->name('dashboard.control')->middleware('checkSession');

//Routes for Category

Route::get('/categories/Insert', [categoryController::class, 'Insert'])->name('categories.store');
Route::post('/categories', [categoryController::class, 'store']);

Route::get('/categories/show', [categoryController::class, 'show'])->name('categories.show');
Route::get('/categories/delete/{id?}', [categoryController::class, 'delete'])->name('categories.delete');



//Routes for Product

// Route::get('/products/show', [productController::class, 'create'])->name('products.show');

Route::get('/products/Insert', [productController::class, 'Insert'])->name('products.store');
Route::post('/products', [productController::class, 'store']);

Route::get('/products/show', [productController::class, 'show'])->name('products.show');
Route::get('/products/delete/{id?}', [productController::class, 'delete'])->name('products.delete');
Route::get('/product/edit/{prodId}', [productController::class, 'edit'])->name('product.edit');
Route::post('/product/update/{prodId}', [productController::class, 'update'])->name('product.update');

//Routes for Suppliers
Route::get('/suppliers/Insert', [supplierController::class, 'Insert'])->name('suppliers.store');
Route::post('/addSupplier', [supplierController::class, 'store']);
Route::get('/suppliers/show', [supplierController::class, 'show'])->name('suppliers.show');
Route::get('/suppliers/delete/{id?}', [supplierController::class, 'delete'])->name('suppliers.delete');







// Route::get('/', function () {
//     return view('welcome');
// });
// //Login Route
// Route::get('/auth/login', [auth::class,'login'])->name('auth.login');

// //Register Route
// Route::get('/auth/register', [auth::class,'register'])->name('auth.register');
// //Save Route
// Route::post('/auth/save', [auth::class,'save'])->name('auth.save');
// //CheckRoute
// Route::post('/auth/check', [auth::class,'check'])->name('auth.check');
// //Log out Route
// Route::
// get('/auth/logout', [auth::class,'logout'])->name('auth.logout');

//Register Route
// Route::get('/auth/register', [auth::class,'register'])->name('auth.register');
// //Save Route
// Route::post('/auth/save', [auth::class,'save'])->name('auth.save');
// //CheckRoute
// Route::post('/auth/check', [auth::class,'doAuthentication'])->name('auth.check');
// //Log out Route
// Route::get('/auth/logout', function () {
//     if(session()->has('sessionName')){
//         session()->pull('sessionName');
//     }
//     return redirect('/auth/login');
// });


// //Login Route
// Route::get('/auth/login', [auth::class,'login'])->name('auth.login');



// Route::get('/dashboard', [dashboardController::class, 'countRows'])->name('dashboard.control');

// //Routes for Users
// // Route::get('/register/create', [RegisterController::class, 'create'])->name('register.user');

// // Route::post('/register', [RegisterController::class, 'store']);

// // Route::get('/register/show', [RegisterController::class, 'show']);

// //Routes for Categories

// // Route::get('/categories/show', [categoryController::class, 'create'])->name('categories.show');

// Route::get('/categories/Insert', [categoryController::class, 'Insert'])->name('categories.store');
// Route::post('/categories', [categoryController::class, 'store']);

// Route::get('/categories/show', [categoryController::class, 'show'])->name('categories.show');


// //Routes for Product

// Route::get('/products/create', [productController::class, 'create'])->name('products.show');

// Route::get('/products/Insert', [productController::class, 'Insert'])->name('products.store');
// Route::post('/products', [productController::class, 'store']);

// Route::get('/products/show', [productController::class, 'show']);

// //Routes for Suppliers
// Route::get('/suppliers/Insert', [supplierController::class, 'Insert'])->name('suppliers.store');
// Route::post('/addSupplier', [supplierController::class, 'store']);
// Route::get('/suppliers/show', [supplierController::class, 'show'])->name('suppliers.show');

// Route::get('/products/cat', [supplierController::class, 'catName'])->name('products.catName');
// Route::get('/products/sup', [supplierController::class, 'supName'])->name('products.supName');
// Route::get('/product/update/{prodId}', [productController::class, 'update'])->name('products.update');

