<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&family=Raleway&display=swap" rel="stylesheet">
    <title>Login Form</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        .container {
            border: 4px solid #000000;
            border-radius: 10px;
            box-shadow: 10px 10px #59595a5a;
        }
    </style>
</head>

<body>
    <section class="vh-100">
        <div class="container h-custom my-5 p-5">
            <div class="row d-flex justify-content-center align-items-center">
                <div class="col-md-9 col-lg-6 col-xl-5">
                    <img src="{{URL('images/signin-image.jpg')}}"
                        class="img-fluid" alt="Sample image" width="400px">
                </div>
                <div class="col-md-8 col-lg-5 col-xl-4">
                    <h1 style="text-align: center;">LOGIN FORM</h1>

                    <form action="{{route('auth.check')}}" method="post">
                        @if (Session::get('fail'))
                            <div class="alert alert-danger">
                                {{Session::get('fail')}}
                        </div>
                        @endif
                        @csrf
                        <div class="form-group mb-3">
                            <label class="form-label" for="username">Username</label>
                            <input type="text" id="username" class="form-control form-control-lg" name="userName" value="{{old('userName')}}" placeholder="Enter UserName"
                                />
                                <span class="text-danger">@error('UserName'){{$message}} @enderror</span>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label" for="pwd">Password</label>
                            <input type="password" id="pwd" class="form-control form-control-lg" name="pwd" value="{{old('pwd')}}"
                                placeholder="Enter password" />
                                <span class="text-danger">@error('pwd'){{$message}} @enderror</span>
                        </div>

                        <div class="text-center text-lg-start mt-4 pt-2">
                            <button type="submit" class="btn btn-primary btn-lg col-lg-7"
                                style="padding-left: 2.5rem; padding-right: 2.5rem;">Login</button>
                            <p class="small fw-bold mt-2 pt-1 mb-0">Don't have an account? <a href="{{route('auth.register') }}"
                                    class="link-danger">Register Here</a></p>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <!-- Right -->
        </div>
    </section>
</body>

</html>
