<!DOCTYPE html>
<html lang="en">
<head>
  <title>Users Data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <h1>Users Data</h1>
  <table class="table">
    <thead>
      <tr>
        <th>User ID</th>
        <th>User FullName</th>
        <th>UserName</th>
        <th>User Email</th>
      </tr>
    </thead>
    <tbody>
        @foreach ($users as $row)


      <tr>
        <td>{{$row->userId}}</td>
        <td>{{$row->userFullName}}</td>
        <td>{{$row->userName}}</td>
        <td>{{$row->userEmail}}</td>
        <td>
            <button type="button" class="btn btn-success"><a href="{{route('dashboard.control')}}" style="color: white; text-decoration: none;">Dashboard</a></button>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>

</body>
</html>


