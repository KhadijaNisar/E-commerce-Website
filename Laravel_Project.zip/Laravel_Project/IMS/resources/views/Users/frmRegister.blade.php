<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ url('https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css') }}"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="preconnect" href="{{ url('https://fonts.googleapis.com') }}">
    <link rel="preconnect" href="{{ url('https://fonts.gstatic.com') }}" crossorigin>
    <link href="{{ url('https://fonts.googleapis.com/css2?family=Poppins:wght@500&family=Raleway&display=swap') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/authStyle.css') }}">
    <title>Signup Form</title>
</head>

<body>
    <section class="vh-100">
        <div class="container h-custom my-3 p-5">
            <div class="row d-flex justify-content-center align-items-center">
                <div class="col-md-9 col-lg-6 col-xl-5">
                    <img src="{{ asset('images/signup-image.jpg') }}" class="img-fluid" alt="Sample image" width="400px">
                </div>
                <div class="col-md-8 col-lg-5 col-xl-4">
                    <h1 style="text-align: center;">SIGNUP FORM</h1>
                    <form action="{{url('/')}}/register" method="post">
                        @csrf
                        <div class="form-group mb-3">
                            <label class="form-label" for="fname">Full Name</label>
                            <input type="text" id="fname" class="form-control form-control-lg" name="fname" value="{{old('fname')}}"
                                placeholder="FullName" required/>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label" for="userName">Username</label>
                            <input type="text" id="userName" class="form-control form-control-lg" name="userName" value="{{old('userName')}}"
                                placeholder="UserName"  required/>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label" for="pwd">Password</label>
                            <input type="password" id="pwd" class="form-control form-control-lg" name="pwd" value="{{old('pwd')}}"
                                placeholder="Enter password" required/>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label" for="email">Email</label>
                            <input type="email" id="email" class="form-control form-control-lg" name="email" value="{{old('email')}}"
                                placeholder="Enter a valid email address" required/>
                        </div>
                        <div class="text-center text-lg-start mt-4 pt-2">
                            <button type="submit" class="btn btn-primary btn-lg col-lg-7"
                                style="padding-left: 2.5rem; padding-right: 2.5rem;">Register</button>
                            <p class="small fw-bold mt-2 pt-1 mb-0">Already Have an Account? <a href=""
                                    class="link-danger">Login Here!</a></p>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <!-- Right -->
        </div>
    </section>
</body>

</html>
