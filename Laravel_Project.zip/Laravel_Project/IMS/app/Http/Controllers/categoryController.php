<?php

namespace App\Http\Controllers;

use App\Models\Tblcategory;
use Illuminate\Http\Request;

class categoryController extends Controller
{
    public function create()
    {
        return view('Categories/frmDisplayAll');
    }

    public function Insert()
    {
        return view('Categories/frmAddCategory');
    }
    public function store(Request $request)
    {
        //print_r($request->all());
        $categories = new Tblcategory;
        $categories->catName = $request['catname'];
        $categories->catBrand = $request['catbrand'];
        $categories->prodQty = $request['noOfProducts'];
        $categories->save();
        return redirect('/categories/show');
    }
    public function show()
    {
        $categories = Tblcategory::all();
        // echo "<pre>";
        // print_r($categories);
        // die();
        $data = compact('categories');
        return view('Categories/frmDisplayAll')->with($data);
    }
}
