<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\admin;
use Illuminate\Support\Facades\Hash;
class auth extends Controller
{
    function doAuthentication(Request $req)
    {
        $data = Admin::where('userName', $req->userName)->first();
        if ($data->userPass == $req->pwd) {
            $req->session()->put('sessionName', $data);
            return redirect('/dashboard');
        } else {
            return redirect('/auth/login');
        }
    }

    function login()
    {
        return view('auth.login');
    }
    function register()
    {
        return view('auth.register');
    }
    function save(Request $request)
    {
        //print_r($request->all());
        //Insert Data into database
        $admin = new Admin;
        $admin->userFullName = $request->fname;
        $admin->userName = $request->userName;
        $admin->userPass = $request->pwd;
        $admin->userEmail = $request->email;
        //return print($admin);
        $admin->save();
        return redirect('/auth/login');
    }
    // //Login method
    // function login()
    // {
    //     return view('auth.login');
    // }
    // //Register method
    // function register()
    // {
    //     return view('auth.register');
    // }
    // //Save method
    // function save(Request $request)
    // {
    //    //Validate requests
    //     $request->validate([
    //        'fname'=>'required',
    //        'userName'=>'required|unique:admin',
    //        'pwd'=>'required',
    //        'email'=>'required|email'
    //     ]);

    //     //Insert Data into database
    //     $admin = new admin;
    //     $admin->userFullName = $request->fname;
    //     $admin->userName = $request->userName;
    //     $admin->userPass =Hash::make($request->pwd);
    //     $admin->userEmail = $request->email;
    //     $save = $admin->save();

    //     if($save){
    //         return redirect('/dashboard')->with('success', 'new user has been added successfully');
    //     }
    //     else{
    //         return back()->with('fail', 'something went wrong,try again');
    //     }
    // }
    // //Check Method
    // function check(Request $request){
    //     //Validate Requests
    //     $request->validate([
    //         'userName'=>'required',
    //         'userPass'=>'required'
    //     ]);
    //     if(\Auth::attempt($request->only('userName','userPass'))){
    //         return $request->all();
    //         // return redirect()->back()->with('success', 'login has been added successfully');
    //     }
    //     return redirect('/auth/register')->withError('login failed');
    //     // $userInfo = admin::where('userName', '=', $request->userName)->first();

    //     // if($userInfo){
    //     //     return back()->with('fail', 'we donot recognize this username');
    //     // }
    //     // else{
    //     //     //check password
    //     //     if(!empty(Hash::check($request->pwd,$userInfo->userPass))){
    //     //         $request->session()->put('LoggedUser',$userInfo->userName);
    //     //         return redirect('admin/register');

    //     //     }
    //     //     else{
    //     //         return back()->with('fail', 'Incorrect Password');
    //     //     }
    //     // }
    // }
    // //Logout method
    // function logout(){
    //     \Session::flush();
    //     \Auth::logout();
    //     return redirect('admin/dashboard');
    // }
}
