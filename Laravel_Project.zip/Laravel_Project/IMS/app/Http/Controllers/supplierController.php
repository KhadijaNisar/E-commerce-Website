<?php

namespace App\Http\Controllers;
use App\Models\Tblsupplier;
use Illuminate\Http\Request;

class supplierController extends Controller
{
    public function create(){
        return view('Suppliers/frmDisplayAll');
    }

    public function Insert()
    {
        return view('Suppliers/frmAddSupplier');
    }
    public function store(Request $request){
        // print_r($request->all());
        $suppliers = new Tblsupplier;
        $suppliers->supplierName = $request['sname'];
        $suppliers->supplierCompany = $request['scompany'];
        $suppliers->supplierPhone = $request['phone'];
        $suppliers->save();
        return redirect('/suppliers/show');
    }
    public function show(){
        $suppliers = Tblsupplier::all();
        // echo "<pre>";
        // print_r($suppliers);
        // die();
        // dd($suppliers);
        // die();
        // $supplier = compact('suppliers');
        return view('Suppliers/frmDisplayAll', compact('suppliers'));



    }
}
