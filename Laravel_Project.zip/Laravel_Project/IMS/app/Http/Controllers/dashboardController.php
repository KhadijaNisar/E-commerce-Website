<?php

namespace App\Http\Controllers;
use App\Models\Admin;
use App\Models\Tblcategory;
use App\Models\TblProduct;
use App\Models\Tblsupplier;
use Illuminate\Http\Request;

class dashboardController extends Controller
{
    public function countRows(){
        $users = new Admin;
        $products = new TblProduct;
        $categories = new Tblcategory;
        $suppliers = new Tblsupplier;

        $products = TblProduct::all();
        $totalProducts = $products->count();

        $categories = Tblcategory::all();
        $totalCategories = $categories->count();

        $users = Admin::all();
        $totalUsers = $users->count();

        $suppliers = Tblsupplier::all();
        $totalSuppliers = $suppliers->count();

        return view('ControlPanel/sidePanel', [
            'totalUsers' => $totalUsers,
            'totalProducts' => $totalProducts,
            'totalCategories' => $totalCategories,
            'totalSuppliers' => $totalSuppliers
        ]);
    }
}
