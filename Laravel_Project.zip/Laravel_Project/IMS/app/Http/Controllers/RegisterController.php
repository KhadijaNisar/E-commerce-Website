<?php

namespace App\Http\Controllers;
use App\Models\Admin;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    public function create(){
        return view('Users/frmRegister');
    }

    // public function register(Request $request){
    //     $request->validate(
    //         [
    //             'fname' => 'required',
    //             'userName' => 'required',
    //             'pwd' => 'required',
    //             'email' => 'required|email'
    //         ]
    //     );
    //     echo "<pre>";
    //     print_r($request->all());
    // }

    public function store(Request $request){
        print_r($request->all());
        $users = new Admin;
        $users->userFullName = $request['fname'];
        $users->userName = $request['userName'];
        $users->userPass = md5($request['pwd']);
        $users->userEmail = $request['email'];
        $users->save();
        return redirect('/register/show');
    }
    public function show(){
        $users = Admin::all();
        // echo "<pre>";
        // print_r($users);
        // die();
        $data = compact('users');
        return view('Users/frmViewUsers')->with($data);
    }
}
