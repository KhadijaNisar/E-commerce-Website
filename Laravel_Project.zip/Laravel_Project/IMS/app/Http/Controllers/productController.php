<?php

namespace App\Http\Controllers;
use App\Models\TblProduct;
use App\Models\Tblcategory;
use App\Models\Tblsupplier;
use Illuminate\Http\Request;

class productController extends Controller
{

    public function create()
    {
        return view('Products/frmDisplayAll');
    }

    public function Insert()
    {
        return view('Products/frmAddProduct');
    }
    public function store(Request $request)
    {
        // print_r($request->all());
        $products = new TblProduct;

        $products->save();
        return redirect('/products/show');
    }
    public function show()
    {
        $products = TblProduct::all();
        $data = compact('products');
        return view('Products/frmDisplayAll')->with($data);
    }
    public function catName()
    {
        $cat = Tblcategory::select('catName');
        return view('frmAddProduct', ['data' => $cat]);
    }
    public function supName()
    {
        $sup = Tblsupplier::select('supplierName');
        return view('frmAddProduct', ['data' => $sup]);
    }
    public function update($prodId)
    {
        $prod = TblProduct::find($prodId);
        if (is_null($prod)) {
            return redirect('Products/frmDisplayAll');
        }
        else{
            return view('frmUpdateProduct.blade.php');
        }
    }
}
