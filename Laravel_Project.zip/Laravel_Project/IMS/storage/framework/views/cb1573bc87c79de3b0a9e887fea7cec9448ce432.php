<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="<?php echo e(url('https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css')); ?>"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css')); ?>"/>
  <link href="<?php echo e(url('//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css')); ?>" rel="stylesheet" id="bootstrap-css">
  <script src="<?php echo e(url('//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js')); ?>"></script>
  <title>Dashboard</title>
</head>

<body>
  <div class="wrapper d-flex align-items-stretch">
    <nav id="sidebar">
      <div class="custom-menu">
        <button type="button" id="sidebarCollapse" class="btn btn-primary">
        </button>
      </div>
      <div class="img bg-wrap text-center py-4"
        style="background-image: url(https://t3.ftcdn.net/jpg/04/59/15/58/360_F_459155812_i8zcXL46AxG1VKNQ5KaxSb6gGpapLuO0.jpg);">
        <div class="user-logo">
          <div class="img" style="background-image: url();"></div>
        </div>
      </div>
      <ul class="list-unstyled components mb-5">
        <li class="active">
          <a href="<?php echo e(route('products.show')); ?>"><span
              class="fa fa-home mr-3"></span>Products</a>
        </li>
        <li>
          <a href="<?php echo e(route('categories.show')); ?>"><span
              class="fa fa-download mr-3 notif"></span>Categories</a>
        </li>
        <li>
          <a href="<?php echo e(route('suppliers.show')); ?>"><span
              class="fa fa-gift mr-3"></span>Suppliers</a>
        </li>
        <li>
          <a href="<?php echo e(route('products.show')); ?>"><span
              class="fa fa-sign-out mr-3"></span>Logout</a>
        </li>
      </ul>

    </nav>

    <!-- Page Content  -->
    <div id="content" class="p-4 p-md-5 pt-5">
      <h1 class="mb-4 my-5">Dashboard</h1>
      <h1>Logged In with Username : arihanoor</h1>
      <div class="row">
        <div class="col-md-3">
          <div class="card-counter primary">
            <i class="fa fa-code-fork"></i>
            <span class="count-numbers">
              <?php echo e($totalProducts); ?>

            </span>
            <span class="count-name">
              <h3>Products</h3>
            </span>
          </div>
        </div>

        <div class="col-md-3">
          <div class="card-counter danger">
            <i class="fa fa-ticket"></i>
            <span class="count-numbers">
                <?php echo e($totalCategories); ?>

            </span>
            <span class="count-name">
              <h3>Categories</h3>
            </span>
          </div>
        </div>

        <div class="col-md-3">
          <div class="card-counter success">
            <i class="fa fa-database"></i>
            <span class="count-numbers">
                <?php echo e($totalSuppliers); ?>

            </span>
            <span class="count-name">
              <h3>Suppliers</h3>
            </span>
          </div>
        </div>

        <div class="col-md-3">
          <div class="card-counter info">
            <i class="fa fa-users"></i>
            <span class="count-numbers">
                <?php echo e($totalUsers); ?>

            </span>
            <span class="count-name">
              <h3>Users</h3>
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="<?php echo e(asset('js/dashboard/jquery.min.js')); ?>"></script>
  <script  src="<?php echo e(asset('js/dashboard/popper.js')); ?>"></script>
  <script  src="<?php echo e(asset('js/dashboard/bootstrap.js')); ?>"></script>
  <script src="<?php echo e(asset('js/dashboard/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH E:\xamp\htdocs\Practice\Laravel_Project\IMS\resources\views/ControlPanel/sidePanel.blade.php ENDPATH**/ ?>