<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&family=Raleway&display=swap" rel="stylesheet">
    <title>Signup Form</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        .container {
            border: 4px solid #000000;
            border-radius: 10px;
            box-shadow: 10px 10px #59595a5a;
        }
    </style>
</head>

<body>
    <section class="vh-100">
        <div class="container h-custom my-3 p-5">
            <div class="row d-flex justify-content-center align-items-center">
                <div class="col-md-9 col-lg-6 col-xl-5">
                    <img src="<?php echo e(URL('images/signup-image.jpg')); ?>" class="img-fluid" alt="Sample image" width="400px">
                </div>
                <div class="col-md-8 col-lg-5 col-xl-4">
                    <h1 style="text-align: center;">SIGNUP FORM</h1>
                    <form action="<?php echo e(route('auth.save')); ?>" method="post">
                        <?php if(Session::get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <?php endif; ?>
                        <?php if(Session::get('fail')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('fail')); ?>

                        </div>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-3">
                            <label class="form-label" for="fname">Full Name</label>
                            <input type="text" id="fname" class="form-control form-control-lg" name="fname" value="<?php echo e(old('fname')); ?>"
                                placeholder="FullName" />
                            <span class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label" for="userName">Username</label>
                            <input type="text" id="userName" class="form-control form-control-lg" name="userName" value="<?php echo e(old('userName')); ?>"
                                placeholder="UserName" />
                                <span class="text-danger"><?php $__errorArgs = ['Username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label" for="pwd">Password</label>
                            <input type="password" id="pwd" class="form-control form-control-lg" name="pwd"
                                placeholder="Enter password" />
                                <span class="text-danger"><?php $__errorArgs = ['Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label" for="email">Email</label>
                            <input type="email" id="email" class="form-control form-control-lg" name="email" value="<?php echo e(old('email')); ?>"
                                placeholder="Enter a valid email address" />
        …
<?php /**PATH E:\xamp\htdocs\Practice\Laravel_Project\IMS\resources\views/auth/register.blade.php ENDPATH**/ ?>